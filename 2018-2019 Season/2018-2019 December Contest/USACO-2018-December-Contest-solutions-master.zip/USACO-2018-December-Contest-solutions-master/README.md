# USACO-2018-December-Contest-solutions
USACO 2018 December Contest C++ solutions
